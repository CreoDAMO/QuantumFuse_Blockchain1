# Soketto

An implementation of the [RFC 6455][1] websocket protocol.
This crate is a heavily modified fork of the [twist][3] crate.

[1]: https://tools.ietf.org/html/rfc6455
[2]: https://crates.io/crates/tokio-codec
[3]: https://crates.io/crates/twist

