# macro_magic_macros

This crate contains proc macros from the [macro_magic](https://crates.io/crates/macro_magic)
crate, which allows for exporting and importing of external items as a `TokenStream2` across
file and crate boundaries when writing proc macros. See the main crate for more information and
to make use of these macros.
