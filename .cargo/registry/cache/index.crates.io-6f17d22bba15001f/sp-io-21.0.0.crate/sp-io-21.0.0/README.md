I/O host interface for substrate runtime.

License: Apache-2.0