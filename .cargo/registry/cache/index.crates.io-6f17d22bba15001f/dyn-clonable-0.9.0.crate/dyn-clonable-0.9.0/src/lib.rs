#[doc(hidden)]
pub use dyn_clone;

// Re-export the attribute macro.
pub use dyn_clonable_impl::*;
