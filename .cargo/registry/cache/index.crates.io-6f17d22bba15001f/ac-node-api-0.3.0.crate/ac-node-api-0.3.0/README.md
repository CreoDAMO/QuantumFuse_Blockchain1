# ac_node_api

This crate is a submodule of the [substrate-api-client](https://github.com/scs/substrate-api-client). It contains Substrate node specific types and helpers such as:
- Strorage keys (key hash, double map, ..)
- Metadata
- Runtime Events
- Runtime Errors
