# sp-version-proc-macro

Auto-generated README.md for publishing to crates.io