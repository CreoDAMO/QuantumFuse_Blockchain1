use wasm_bindgen::prelude::*;

#[wasm_bindgen(main)]
async fn main() {}

#[wasm_bindgen(main)]
fn fail() {}
