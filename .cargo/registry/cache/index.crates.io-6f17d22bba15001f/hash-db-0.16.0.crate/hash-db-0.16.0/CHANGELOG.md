# Changelog

The format is based on [Keep a Changelog].

[Keep a Changelog]: http://keepachangelog.com/en/1.0.0/

## [0.16.0] - 2023-03-14
- Requires Hash to be Ord. [#188](https://github.com/paritytech/trie/pull/188)


