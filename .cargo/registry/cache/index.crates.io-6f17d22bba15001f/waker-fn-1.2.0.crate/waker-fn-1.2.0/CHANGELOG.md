# Version 1.2.0

- Add a new `portable-atomic` feature that allows for the usage of the
  `portable-atomic` crate to implement `waker-fn`. (#10)

# Version 1.1.1

- Reimplement using 100% safe code. (#7)

# Version 1.1.0

- Make the crate `#![no_std]`.

# Version 1.0.0

- Initial version.
