# base58
Tiny and fast base58 encoding

Based on [trezor's implementation](https://github.com/trezor/trezor-crypto/blob/master/base58.c)

[![Build Status][travis-image]][travis-url]

[travis-image]: https://travis-ci.org/debris/base58.svg?branch=master
[travis-url]: https://travis-ci.org/debris/base58

[Documentation](http://debris.github.io/base58/base58/index.html)
