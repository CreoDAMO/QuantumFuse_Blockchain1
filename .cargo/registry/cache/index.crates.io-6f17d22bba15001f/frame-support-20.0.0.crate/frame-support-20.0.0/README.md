Support code for the runtime.

License: Apache-2.0