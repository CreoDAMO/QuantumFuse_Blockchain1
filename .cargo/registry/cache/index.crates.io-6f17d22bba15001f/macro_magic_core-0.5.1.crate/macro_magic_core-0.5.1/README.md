Contains the implementation for [macro_magic](https://crates.io/crates/macro_magic)'s macros.
