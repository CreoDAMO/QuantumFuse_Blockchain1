# 0.1.2

Drop futures after they have resolved. Add another internal state to
better distinguish failures from ordinary closures.

# 0.1.1

On error the sink immediately transitions to a closed state (#3).

# 0.1.0

Initial release.
