# rustc-hex

---

`rustc-serialize` compatible hex conversion traits
