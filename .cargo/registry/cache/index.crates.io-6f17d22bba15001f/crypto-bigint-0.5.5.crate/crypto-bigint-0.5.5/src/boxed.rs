//! Heap-allocated "boxed" types.

pub(crate) mod uint;
