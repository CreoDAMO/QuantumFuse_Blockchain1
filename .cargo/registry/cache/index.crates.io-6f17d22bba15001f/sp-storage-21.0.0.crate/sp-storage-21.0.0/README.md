Primitive types for storage related stuff.

License: Apache-2.0
