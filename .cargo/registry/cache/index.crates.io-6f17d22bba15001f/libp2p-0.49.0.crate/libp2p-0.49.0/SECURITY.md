# Security Policy

## Supported Versions

By default we provide security patches for the latest released version only. On request we patch older versions.

## Reporting a Vulnerability

Please reach out to security@libp2p.io. Please do not file a public issue on GitHub.
