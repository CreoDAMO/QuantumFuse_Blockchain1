package org.zfnd.ed25519

import org.scalatest.Tag

object PemTest extends Tag("PemTest")
object Pkcs8Test extends Tag("Pkcs8Test")
