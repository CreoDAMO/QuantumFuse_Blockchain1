# sp-core-hashing-proc-macro

Auto-generated README.md for publishing to crates.io