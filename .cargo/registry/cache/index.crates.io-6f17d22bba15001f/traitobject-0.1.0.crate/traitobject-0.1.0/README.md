# traitobject

> Unsafe helpers for dealing with raw trait objects.

## Usage

Use the crates.io repository; add this to your `Cargo.toml` along
with the rest of your dependencies:

```toml
[dependencies]
traitobject = "*"
```

## Author

[Jonathan Reem](https://medium.com/@jreem) is the primary author and maintainer
of traitobject.

## License

MIT/Apache-2.0

