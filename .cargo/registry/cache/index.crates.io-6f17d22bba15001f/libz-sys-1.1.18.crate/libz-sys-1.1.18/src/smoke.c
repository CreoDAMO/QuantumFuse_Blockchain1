#include <zlib.h>

int main() {
  return (int) adler32;
}
