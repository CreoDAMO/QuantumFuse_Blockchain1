bip39
=====

This is *unmaintained*, *temporary* fork of: https://github.com/rust-bitcoin/rust-bip39/. Its purpose it to create a short-term release on crates.io to facilitate progress on polkadot-sdk.
This action was prompted by delays in merging process of:
- https://github.com/rust-bitcoin/rust-bip39/pull/57 
- https://github.com/rust-bitcoin/rust-bip39/pull/64

