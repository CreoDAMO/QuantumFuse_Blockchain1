# unicase

[![Build Status](https://travis-ci.org/seanmonstar/unicase.svg?branch=master)](https://travis-ci.org/seanmonstar/unicase)

Compare strings when case is not important.

```rust
if UniCase(method) == UniCase('GET') {
    // GET request
}
```

## License

[MIT](./LICENSE)
