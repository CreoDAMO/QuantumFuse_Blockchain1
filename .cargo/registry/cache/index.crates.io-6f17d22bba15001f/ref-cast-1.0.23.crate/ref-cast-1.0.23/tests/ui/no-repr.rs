use ref_cast::RefCast;

#[derive(RefCast)]
struct Test {
    s: String,
}

fn main() {}
