# ac_primitives

This crate is a submodule of the [substrate-api-client](https://github.com/scs/substrate-api-client). It contains macro definition for creating Substrate extrinsic and rpc calls for the api-client.
