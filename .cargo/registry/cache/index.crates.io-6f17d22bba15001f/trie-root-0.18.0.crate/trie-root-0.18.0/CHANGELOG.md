# Changelog

The format is based on [Keep a Changelog].

[Keep a Changelog]: http://keepachangelog.com/en/1.0.0/

## [Unreleased]


## [0.18.0] - 2023-03-14
- Update dependencies. [#188](https://github.com/paritytech/trie/pull/188) and [#187](https://github.com/paritytech/trie/pull/187)

## [0.17.0] - 2021-10-19
- Support for value nodes. [#142](https://github.com/paritytech/trie/pull/142)

## [0.16.0] - 2020-02-07
- Update reference-trie to v0.20.0 [#78](https://github.com/paritytech/trie/pull/78)
