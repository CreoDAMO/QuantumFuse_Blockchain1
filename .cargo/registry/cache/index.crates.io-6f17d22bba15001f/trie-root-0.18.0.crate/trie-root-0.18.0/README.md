This crate provides utility functions to validate and initialize tries using flexible input.
It is used extensively in `substrate` to validate blocks (mostly transactions and receipt roots).
