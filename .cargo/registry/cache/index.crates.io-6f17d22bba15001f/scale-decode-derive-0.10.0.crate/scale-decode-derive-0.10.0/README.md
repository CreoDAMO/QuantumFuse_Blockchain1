# scale-decode-derive

Provides a `DecodeAsType` macro capable of automatically implementing `DecodeAsType` (via implementing `IntoVisitor` / `Visitor` traits) on structs and enums.