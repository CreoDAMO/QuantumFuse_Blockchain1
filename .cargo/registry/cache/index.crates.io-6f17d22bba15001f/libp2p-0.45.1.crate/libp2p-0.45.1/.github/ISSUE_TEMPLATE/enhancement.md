---
name: Enhancement
about: Suggest an improvement to an existing rust-libp2p feature.
---

## Description

<!-- Describe the enhancement that you are proposing.-->

## Motivation

<!-- Explain why this enhancement is beneficial.-->

## Current Implementation

<!-- Describe the current implementation. -->

## Are you planning to do it yourself in a pull request?

<!--Any contribution is greatly appreciated. We are more than happy to provide help on the process.-->

Yes / No / Maybe.
