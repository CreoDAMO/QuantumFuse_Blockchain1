Lowest-abstraction level for the Substrate runtime: just exports useful primitives from std
or client/alloc to be used with any code that depends on the runtime.

License: Apache-2.0
