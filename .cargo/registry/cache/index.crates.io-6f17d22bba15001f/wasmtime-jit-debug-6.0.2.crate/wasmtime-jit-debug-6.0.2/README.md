This is the `wasmtime-jit-debug` crate, which contains JIT debug interfaces support for Wasmtime.
