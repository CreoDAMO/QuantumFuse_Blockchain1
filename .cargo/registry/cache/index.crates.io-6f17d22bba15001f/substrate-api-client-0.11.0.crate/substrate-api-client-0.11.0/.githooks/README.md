# githooks

Copy these files to `.git/hooks`
