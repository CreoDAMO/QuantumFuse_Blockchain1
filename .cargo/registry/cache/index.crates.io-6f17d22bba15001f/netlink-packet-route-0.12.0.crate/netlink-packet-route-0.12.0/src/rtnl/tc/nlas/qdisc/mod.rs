// SPDX-License-Identifier: MIT

pub mod ingress {
    pub const KIND: &str = "ingress";
}
