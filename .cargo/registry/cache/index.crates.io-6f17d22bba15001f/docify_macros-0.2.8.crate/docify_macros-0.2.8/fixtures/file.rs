#[docify::export]
fn some_fn() {
    println!("foo");
}

#[docify::export]
fn some_other_fn() {
    println!("bar");
}
