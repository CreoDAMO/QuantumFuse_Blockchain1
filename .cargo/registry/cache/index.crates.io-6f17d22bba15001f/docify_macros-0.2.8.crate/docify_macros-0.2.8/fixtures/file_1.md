# This is a markdown file

```rust
struct Something;
```
<!-- this is a comment -->

<!-- docify::embed!("fixtures/file.rs", some_fn) -->

Some text this is some text
