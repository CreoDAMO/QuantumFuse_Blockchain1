**WARNING: THIS PROJECT IS IN MAINTENANCE MODE, DUE TO INSUFFICIENT MAINTAINER RESOURCES**

It works fine, but will generally no longer be improved.

We are currently only accepting changes which:

* keep this compiling with the latest versions of Rust or its dependencies.
* have minimal review requirements, such as documentation changes (so not totally new APIs).

------

A cache that holds a limited number of key-value pairs.

Documentation is available at https://contain-rs.github.io/lru-cache/lru_cache.
