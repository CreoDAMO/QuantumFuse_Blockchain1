A crate which contains primitives that are useful for implementation that uses staking
approaches in general. Definitions related to sessions, slashing, etc go here.

License: Apache-2.0