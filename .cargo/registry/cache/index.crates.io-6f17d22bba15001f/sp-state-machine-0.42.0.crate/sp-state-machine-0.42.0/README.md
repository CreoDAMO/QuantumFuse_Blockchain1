Substrate state machine implementation.

License: Apache-2.0
