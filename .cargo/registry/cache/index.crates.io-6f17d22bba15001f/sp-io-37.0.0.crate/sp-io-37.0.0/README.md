I/O host interface for Substrate runtime.

License: Apache-2.0
