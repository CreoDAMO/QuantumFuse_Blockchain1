Runtime Modules shared primitive types.

License: Apache-2.0