# Changelog

## v0.1 Changes from inside substrate tree

- try_from(u16), try_from(u8) => from(u16) and from(u8) as the conversions are infallable.
