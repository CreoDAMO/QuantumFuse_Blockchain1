Traits and macros for constructing application specific strongly typed crypto wrappers.

License: Apache-2.0