# Chapter 3

This file demonstrates the ability to end a markdown file with an example, and one that has a
lot of comments in it for that matter:

<!-- docify::embed!("examples/samples.rs", some_example) -->
