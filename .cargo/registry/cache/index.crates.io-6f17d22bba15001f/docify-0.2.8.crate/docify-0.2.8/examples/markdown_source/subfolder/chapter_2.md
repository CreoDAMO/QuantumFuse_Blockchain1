# Chapter 2

This demonstrates the ability to have multiple embeds in the same file, and have exotic spacing
inside your HTML comments:

<!--

    docify::embed!("examples/samples.rs", SomeImpl)  
-->

This is the text after the embed
