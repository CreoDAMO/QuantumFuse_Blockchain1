# Chapter 1
This is a markdown book. It has content and stuff in it. It can also have docify embeds
anywhere we want, for example, here is an embed from the `samples.rs` file demonstrating that
we can use an optional semicolon and import multiple examples with the same name:

<!-- docify::embed!("examples/samples.rs", Duplicate); -->

This is the content after the 3 examples above.
