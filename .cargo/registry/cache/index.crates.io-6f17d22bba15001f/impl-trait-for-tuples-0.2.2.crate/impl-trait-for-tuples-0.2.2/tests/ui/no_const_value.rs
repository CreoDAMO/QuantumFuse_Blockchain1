#[impl_trait_for_tuples::impl_for_tuples(1)]
trait Test {
	const Test: u32;
}

fn main() {}
