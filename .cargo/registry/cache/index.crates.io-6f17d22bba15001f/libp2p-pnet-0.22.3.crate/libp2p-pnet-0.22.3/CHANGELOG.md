# 0.22.3

- Fix handshake over websocket. See [PR 3476]

[PR 3476]: https://github.com/libp2p/rust-libp2p/pull/3476

# 0.22.2

- Update `rust-version` to reflect the actual MSRV: 1.60.0. See [PR 3090].

[PR 3090]: https://github.com/libp2p/rust-libp2p/pull/3090

# 0.22.1

- Bump rand to 0.8 and quickcheck to 1. See [PR 2857].

- Bump async-std-resolver and trust-dns-resolver from 0.21 to 0.22. See [PR 2988].

- Bump salsa20 to 0.10. See [PR 2989].

[PR 2857]: https://github.com/libp2p/rust-libp2p/pull/2857
[PR 2988]: https://github.com/libp2p/rust-libp2p/pull/2988
[PR 2989]: https://github.com/libp2p/rust-libp2p/pull/2989

# 0.22.0 [2021-11-01]

- Update dependencies.

- Migrate to Rust edition 2021 (see [PR 2339]).

[PR 2339]: https://github.com/libp2p/rust-libp2p/pull/2339

# 0.21.0 [2021-05-17]

- Update dependencies.

# 0.20.0 [2020-12-17]

- Update dependencies.

# 0.19.2 [2020-10-16]

- Update dependencies.

# 0.19.1 [2020-06-22]

- Updated dependencies.
