Internal proc-macro crate in support of [macro_magic](https://crates.io/crates/macro_magic).
