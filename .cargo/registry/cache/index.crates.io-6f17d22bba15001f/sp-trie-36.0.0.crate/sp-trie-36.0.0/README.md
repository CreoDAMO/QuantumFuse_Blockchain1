Utility functions to interact with Substrate's Base-16 Modified Merkle Patricia tree ("trie").

License: Apache-2.0
