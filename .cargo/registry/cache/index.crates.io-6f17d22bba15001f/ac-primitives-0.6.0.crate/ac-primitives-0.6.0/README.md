# ac_primitives

This crate is a submodule of the [substrate-api-client](https://github.com/scs/substrate-api-client). It contains primitives types and helpers used by the api-client and its submodules.
