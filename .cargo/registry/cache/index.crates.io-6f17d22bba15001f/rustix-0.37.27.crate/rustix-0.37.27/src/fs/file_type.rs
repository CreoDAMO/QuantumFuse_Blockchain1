use crate::backend;

/// `S_IF*` constants.
pub use backend::fs::types::FileType;
