export declare const addFunction: (func: () => void) => void;
export declare const attachFunctions: () => void;
