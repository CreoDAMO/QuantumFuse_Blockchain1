function t(r) {
  return typeof r == "object" && "length" in r ? r : Array.from(r);
}
export {
  t as a
};
//# sourceMappingURL=array-2ff2c7a6.js.map
