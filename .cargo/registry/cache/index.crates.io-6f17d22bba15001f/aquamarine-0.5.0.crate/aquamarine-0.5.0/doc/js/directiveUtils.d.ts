export declare const parseDirective: (p: any, statement: string, context: string, type: string) => void;
