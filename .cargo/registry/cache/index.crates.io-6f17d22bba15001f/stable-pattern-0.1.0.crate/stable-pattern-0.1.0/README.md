# stable-pattern &thinsp; [![crates.io]][crate] [![docs.rs]][docs]

[crates.io]: https://img.shields.io/crates/v/stable-pattern.svg
[crate]: https://crates.io/crates/stable-pattern
[docs.rs]: https://docs.rs/stable-pattern/badge.svg
[docs]: https://docs.rs/stable-pattern

Stable, `no_std` port of [`std::str::pattern`], Rust 1.52.

[`std::str::pattern`]: https://doc.rust-lang.org/stable/std/str/pattern/index.html
