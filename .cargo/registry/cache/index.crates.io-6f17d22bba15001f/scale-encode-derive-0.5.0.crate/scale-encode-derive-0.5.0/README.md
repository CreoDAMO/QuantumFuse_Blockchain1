# scale-encode-derive

Provides an `EncodeAsType` macro capable of automatically implementing `EncodeAsType` on structs and enums.