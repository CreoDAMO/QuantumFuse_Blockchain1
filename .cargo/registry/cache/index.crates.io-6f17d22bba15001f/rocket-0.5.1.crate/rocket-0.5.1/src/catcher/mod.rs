//! Types and traits for error catchers and their handlers and return types.

mod catcher;
mod handler;

pub use catcher::*;
pub use handler::*;
