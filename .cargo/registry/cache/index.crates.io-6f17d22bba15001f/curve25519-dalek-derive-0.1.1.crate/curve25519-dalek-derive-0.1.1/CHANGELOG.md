# Changelog

Entries are listed in reverse chronological order per undeprecated
major series.

### 0.1.1

* Copied over license files from [original](https://github.com/koute/unsafe_target_feature/tree/389ae00d34cf0ff589cb8d9b38a85ae1b05ebfdc) repo
