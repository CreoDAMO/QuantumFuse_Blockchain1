Substrate genesis builder.

Refer to the module doc for more details.

License: Apache-2.0
