Types and traits for interfacing between the host and the wasm runtime.

License: Apache-2.0
