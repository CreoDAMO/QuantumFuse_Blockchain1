#![deny(deprecated)]

use pin_project::{project, project_ref, project_replace};

#[project]
#[project_ref]
#[project_replace]
fn main() {}
