# 0.3.0

- Move from https://github.com/paritytech/rw-stream-sink/ to https://github.com/libp2p/rust-libp2p. See [Issue 2504].

- Update to Rust edition 2021.

[Issue 2504]: https://github.com/libp2p/rust-libp2p/issues/2504