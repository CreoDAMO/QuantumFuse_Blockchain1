# Actual Generated Schemas

If a test fails because a generated schema did not match the expected JSON, then the actual schema will be written to a JSON file in this directory.