Decodable variant of the RuntimeMetadata.

This really doesn't belong here, but is necessary for the moment. In the future
it should be removed entirely to an external module for shimming on to the
codec-encoded metadata.

License: Apache-2.0