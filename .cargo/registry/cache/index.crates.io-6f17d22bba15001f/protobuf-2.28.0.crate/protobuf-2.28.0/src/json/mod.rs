//! JSON serialization and deserialization.
//!
//! (Implemented in master, but not ported to stable branch yet).

mod json_name;

#[doc(hidden)]
pub use self::json_name::json_name;
