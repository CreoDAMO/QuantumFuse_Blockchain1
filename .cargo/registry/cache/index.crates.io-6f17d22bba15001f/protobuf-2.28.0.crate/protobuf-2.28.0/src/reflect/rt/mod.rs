//! This module contains functions references for reflection in generated code.

#![doc(hidden)]

pub use crate::reflect::acc::FieldAccessor;
