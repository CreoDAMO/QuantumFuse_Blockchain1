pub mod com {
    pub mod prost_test {
        pub mod test {
            pub mod v1 {
                include!("com.prost_test.test.v1.rs");
            }
        }
    }
}
