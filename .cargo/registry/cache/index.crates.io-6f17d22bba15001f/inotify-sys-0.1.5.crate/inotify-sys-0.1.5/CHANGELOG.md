<a name="v0.1.5"></a>
### v0.1.5 (2021-01-16)

- Add LICENSE file ([#21])

[#21]: https://github.com/hannobraun/inotify-sys/pull/21


<a name="v0.1.4"></a>
### v0.1.4 (2020-11-06)

- Fix build by no longer failing on warnings


<a name="v0.1.3"></a>
### v0.1.3 (2018-07-26)

#### Bug Fixes

*   Use platform-specific constants from libc ([b363dff1](b363dff1))
