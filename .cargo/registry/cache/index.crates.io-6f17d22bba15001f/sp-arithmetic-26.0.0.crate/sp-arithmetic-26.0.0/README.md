Minimal fixed point arithmetic primitives and types for runtime.

License: Apache-2.0
