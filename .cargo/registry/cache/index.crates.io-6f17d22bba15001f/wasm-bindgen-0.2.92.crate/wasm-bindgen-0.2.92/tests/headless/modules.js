export function get_five() {
  return 5;
}
