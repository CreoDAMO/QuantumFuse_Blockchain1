# mime.rs

[![Build Status](https://travis-ci.org/hyperium/mime.rs.svg?branch=master)](https://travis-ci.org/hyperium/mime.rs)

Support MIME (Media Types) as strong types in Rust.

[Documentation](http://hyperium.github.io/mime.rs)

## License

[MIT](./LICENSE)
