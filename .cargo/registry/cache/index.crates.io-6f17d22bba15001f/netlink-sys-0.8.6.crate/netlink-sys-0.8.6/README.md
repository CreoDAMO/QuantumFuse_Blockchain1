# Rust netlink-sys crate

The netlink_sys crate provides netlink sockets.
Integration with mio and tokio is optional.

[Rust crate Document](https://docs.rs/netlink-sys/)
