//! As of autocfg 0.1.8, this is simply re-exporting from autocfg 1.1.0 or later.
//! Please upgrade and refer to the newer version for current documentation!

extern crate autocfg;

pub use autocfg::{emit, new, rerun_env, rerun_path, AutoCfg, Error};
