use sp_runtime_interface::pass_by::PassByEnum;

#[derive(PassByEnum)]
struct Test;

fn main() {}
