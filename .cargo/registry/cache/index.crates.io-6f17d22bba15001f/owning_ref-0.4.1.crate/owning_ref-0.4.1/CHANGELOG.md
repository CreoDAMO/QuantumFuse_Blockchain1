# Changelog

## [0.4.1] - 2020-02-27
### Added
- `map_with_owner` (#51)

### Changed
- Use dyn for trait objects (#53)
