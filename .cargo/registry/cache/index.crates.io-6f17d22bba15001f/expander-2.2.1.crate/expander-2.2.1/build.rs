fn main() {
    // dummy main, we only need `OUT_DIR`
}
