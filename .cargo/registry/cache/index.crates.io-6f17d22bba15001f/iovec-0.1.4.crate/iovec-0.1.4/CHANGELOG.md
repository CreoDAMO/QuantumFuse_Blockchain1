# 0.1.4 (October 9, 2019)

* Add missing `repr(C)`.

# 0.1.3 (yanked) (October 8, 2019)

* Remove dependency on old winapi 0.2 (#16)

# 0.1.2 (January 26th, 2018)

* Add support for non-windows/unix targets (#10)

# 0.1.1 (October 5th, 2017)

* Fix soundness bug: Assert slice lengths are always > 0 (#5)

# 0.1.0 (March 14th, 2017)

* Initial release
