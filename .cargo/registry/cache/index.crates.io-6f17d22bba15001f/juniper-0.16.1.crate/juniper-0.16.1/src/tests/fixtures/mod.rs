//! Library fixtures

/// GraphQL schema and data from Star Wars.
pub mod starwars;
