//! Exposition format implementations.

pub mod text;
