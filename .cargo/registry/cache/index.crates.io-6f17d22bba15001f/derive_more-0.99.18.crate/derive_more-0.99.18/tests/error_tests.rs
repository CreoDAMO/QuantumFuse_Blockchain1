#[macro_use]
extern crate derive_more;

mod error;
