Version module for the Substrate runtime; Provides a function that returns the runtime version.

License: Apache-2.0